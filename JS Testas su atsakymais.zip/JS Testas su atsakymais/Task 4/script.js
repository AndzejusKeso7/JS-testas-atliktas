/* ------------------------------ TASK 4 -----------------------------------
Parašykite JS kodą, vartotjui atėjus į tinkaį kreipsis į cars.json failą
ir iš atvaizduos visus automobilių gamintojus ir pagamintus modelius. 
Kiekvienas gamintojas turės savo atvaizdavimo "kortelę", kurioje bus 
nurodomas gamintojas ir jo pagaminti modeliai.


Pastaba: Informacija apie automobilį (brand) (jo kortelė) bei turi turėti 
bent minimalų stilių;
-------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function () {
    fetch('./cars.json')
      .then(response => response.json())
      .then(data => {
        displayBrands(data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  });
  
  function displayBrands(carsData) {
    const output = document.getElementById('output');
  
    carsData.forEach(brand => {
      const brandCard = document.createElement('div');
      brandCard.classList.add('brand-card');

      brandCard.innerHTML = `<h2>${brand.brand}</h2>`;
  
      brand.models.forEach(model => {
        const modelInfo = document.createElement('p');
        modelInfo.textContent = model;
        brandCard.appendChild(modelInfo);
      });

      output.appendChild(brandCard);
    });
  }
  